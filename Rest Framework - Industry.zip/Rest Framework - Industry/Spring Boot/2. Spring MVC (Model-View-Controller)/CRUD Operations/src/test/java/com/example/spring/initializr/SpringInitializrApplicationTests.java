package com.example.spring.initializr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringInitializrApplicationTests {

	@Test
	void contextLoads() {
	}

}
