package com.example.spring.initializr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringInitializrApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringInitializrApplication.class, args);
	}

}
